package robotService.models.robots;

public class Cleaner extends BaseRobot {
    public Cleaner(String name, int energy, int happiness, int procedureTime) {
        super(name, energy, happiness, procedureTime);
    }
}
